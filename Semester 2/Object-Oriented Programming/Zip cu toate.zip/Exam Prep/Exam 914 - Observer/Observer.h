//
// Created by Th on 14/06/2023.
//

#ifndef EXAMPREP914_OBSERVER_H
#define EXAMPREP914_OBSERVER_H


class Observer {
public:
    virtual void update() = 0;
};


#endif //EXAMPREP914_OBSERVER_H
