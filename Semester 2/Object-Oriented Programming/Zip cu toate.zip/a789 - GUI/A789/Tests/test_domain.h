//
// Created by Th on 31/05/2023.
//

#ifndef A789_TEST_DOMAIN_H
#define A789_TEST_DOMAIN_H

#include <string>
using namespace std;
class Test_Domain{

public:

    void TestSetQuantity();

    void TestSetPrice();

    void TestGetSize();

    void TestGetColor();

    void TestGetPrice();

    void TestGetQuantity();

    void TestGetPhotograph();

    void TestAllDomain();

};

#endif //A789_TEST_DOMAIN_H
