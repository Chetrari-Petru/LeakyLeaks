//
// Created by Th on 31/05/2023.
//

#ifndef A789_TEST_SERVICE_H
#define A789_TEST_SERVICE_H


class Test_Service {

public:

    void TestGetTotalPrice();

    void TestAddUserService();

    void TestAddService();

    void TestDeleteService();

    void TestUpdatePriceService();

    void TestUpdateQuantityService();

    void TestGetSize();

    void TestAllService();
};


#endif //A789_TEST_SERVICE_H
