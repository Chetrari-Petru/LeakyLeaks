//
// Created by Th on 31/05/2023.
//

#ifndef A789_TEST_VALIDATION_H
#define A789_TEST_VALIDATION_H

class Test_Validation {

public:

    void test_validate_color_product();

    void test_validate_size_product();

    void test_validate_price_product();

    void test_validate_quantity_product();

    void test_validate_photograph_product();

    void TestAllValidation();

};


#endif //A789_TEST_VALIDATION_H
