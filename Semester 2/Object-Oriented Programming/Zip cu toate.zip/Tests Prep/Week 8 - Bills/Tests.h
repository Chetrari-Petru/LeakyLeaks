//
// Created by theo on 25.04.2023.
//

#ifndef WEEK_8___TEST_PREP_TESTS_H
#define WEEK_8___TEST_PREP_TESTS_H
#include "Repository.h"
#include "Controller.h"

class Tests {
public:
    static void testAddBill();
    static void testTotalSumOfBills();
};


#endif //WEEK_8___TEST_PREP_TESTS_H
