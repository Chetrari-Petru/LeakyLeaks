//
// Created by theo on 26.04.2023.
//

#ifndef T1_913_FINTINA_OLIVIA_1_TESTS_H
#define T1_913_FINTINA_OLIVIA_1_TESTS_H

#include "Domain.h"
#include "Repository.h"
#include "Controller.h"


class Tests {
public:
    static void testAddPlayer();
    static void testGetPlayersByTeam();
};


#endif //T1_913_FINTINA_OLIVIA_1_TESTS_H
